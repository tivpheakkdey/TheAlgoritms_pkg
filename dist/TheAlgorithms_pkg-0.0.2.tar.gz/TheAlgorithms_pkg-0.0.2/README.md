#Library Package

This package is prototype to demonstrate how the finally product will be package up.
Currently included in the package folder are some implemetation from the GitHub project plus one additional algorithm not in the project:
* caesar_cipher.py
* vigenere_cipher.py
* xor_cipher.py
* autokey_cipher.py (new)
